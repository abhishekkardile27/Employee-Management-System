package in.sb.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.sb.main.entity.Employee;
import in.sb.main.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository repository;

    @Override
    public Employee saveEmployee(Employee employee) {
        return repository.save(employee);
    }

    @Override
    public List<Employee> getAllEmployees() {
        return repository.findAll();
    }
	
    // UPDATE EMPLOYEE
    @Override
    public Employee updateEmployee(Long id, Employee employee) {

        Employee existingEmployee = repository.findById(id).orElse(null);

        existingEmployee.setName(employee.getName());
        existingEmployee.setEmail(employee.getEmail());
        existingEmployee.setDepartment(employee.getDepartment());

        return repository.save(existingEmployee);
    }

    // DELETE EMPLOYEE
    @Override
    public boolean deleteEmployee(Long id) {
        repository.deleteById(id);
		return false;
    }

	@Override
	public Employee getEmployeeById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	
}