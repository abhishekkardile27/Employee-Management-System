package in.sb.main.service;

import java.util.List;

import in.sb.main.entity.Employee;

public interface EmployeeService  {
	
	
	
	Employee saveEmployee(Employee employee);
    List<Employee> getAllEmployees();
    Employee getEmployeeById(Long id);
    Employee updateEmployee(Long id, Employee employee);
    boolean deleteEmployee(Long id);
	

}
